#!/bin/bash
max=29
for i in `seq 1 $max`
do
    ./rank-aggregation-partial
done