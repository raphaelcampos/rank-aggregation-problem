#ifndef __I_K_STRUCTURE__
#define __I_K_STRUCTURE__

#include "IGraph.h"
#include "Graph_Adj_Matrix2.hpp"
#include "Permutation/PermutationTree.hpp"

#endif