#!/bin/bash

for (( i = 0; i < 30; i++ )); do
	./time-measure-aggr
done	