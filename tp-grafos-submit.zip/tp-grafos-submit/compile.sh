#!/bin/bash
g++ -O3 tp-graph.cpp -o tp-graph