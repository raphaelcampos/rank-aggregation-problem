#ifndef DLIB_REVISION_H
// Version:  18.15
// Date:     Wed Apr 29 21:37:32 EDT 2015
// Mercurial Revision ID:  feaff82884de
#define DLIB_MAJOR_VERSION  18
#define DLIB_MINOR_VERSION  15
#endif
